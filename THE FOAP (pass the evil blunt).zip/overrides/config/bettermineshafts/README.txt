This directory is for adding YUNG's Better Mineshafts advanced options.
Options provided may vary by version.

NOTE - AS OF 1.18.2, MINESHAFT CUSTOMIZATION IS NOW DONE VIA DATA PACK!

THE FOLLOWING INSTRUCTIONS APPLY TO VERSIONS BEFORE 1.18.2:

This directory contains subdirectories for supported versions. The first time you run Better Mineshafts, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Mineshafts for Minecraft Forge 1.18, the 'forge-1_18 subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support advanced options.